-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.11.13-MariaDB-0ubuntu0.24.04.1 - Ubuntu 24.04
-- SO del servidor:              debian-linux-gnu
-- HeidiSQL Versión:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla inventario_inmuebles.area: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.asignacion: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.cache: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.cache_locks: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.causa: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.electronico: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.empleado: ~2 rows (aproximadamente)
INSERT IGNORE INTO `empleado` (`id`, `primer_nombre`, `segundo_nombre`, `primer_apellido`, `segundo_apellido`, `id_usuario`, `estado`) VALUES
	(1, 'Diego', 'Alexander', 'Rodriguez', 'Garcia', NULL, 'activo'),
	(2, 'Sandra', 'Alejandra', 'Diaz', 'Aguilar', NULL, 'activo');

-- Volcando datos para la tabla inventario_inmuebles.equipo: ~2 rows (aproximadamente)
INSERT IGNORE INTO `equipo` (`id`, `identificador`, `tipo_elemento`, `nombre`, `id_marca`, `color`, `valor`, `serie`, `extras`, `tipo_alimentacion`, `id_empleado`, `estado`, `fecha_commit`) VALUES
	(1, 'INF-000001', 'informatica', 'Inspiron 14 ', 1, 'Azul', 4500.00, 'ASHG082934', '', '110v', NULL, 'activo', '2025-10-18 09:40:55'),
	(2, 'INF-000002', 'informatica', 'PROBOOK 8', 2, 'PLATEADO', 5200.00, 'KLIS097628', 'Se deberá de cuidar el equipo informático, quedará bajo su responsabilidad.', '110v', 2, 'activo', '2025-10-18 09:44:48');

-- Volcando datos para la tabla inventario_inmuebles.herramienta: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.imagen: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.log_movimiento: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.mantenimiento: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.marca: ~11 rows (aproximadamente)
INSERT IGNORE INTO `marca` (`id`, `nombre`) VALUES
	(1, 'Dell'),
	(2, 'HP'),
	(3, 'Lenovo'),
	(4, 'ThinkPad'),
	(5, 'Acer'),
	(6, 'Asus'),
	(7, 'Apple'),
	(8, 'Microsoft'),
	(9, 'Samsung'),
	(10, 'Toshiba'),
	(11, 'Otros');

-- Volcando datos para la tabla inventario_inmuebles.migrations: ~30 rows (aproximadamente)
INSERT IGNORE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2025_08_29_060705_create_area_table', 1),
	(2, '2025_08_29_060705_create_asignacion_table', 1),
	(3, '2025_08_29_060705_create_causa_table', 1),
	(4, '2025_08_29_060705_create_electronico_table', 1),
	(5, '2025_08_29_060705_create_empleado_table', 1),
	(6, '2025_08_29_060705_create_equipo_table', 1),
	(7, '2025_08_29_060705_create_herramienta_table', 1),
	(8, '2025_08_29_060705_create_imagen_table', 1),
	(9, '2025_08_29_060705_create_log_movimiento_table', 1),
	(10, '2025_08_29_060705_create_mantenimiento_table', 1),
	(11, '2025_08_29_060705_create_marca_table', 1),
	(12, '2025_08_29_060705_create_mobiliario_table', 1),
	(13, '2025_08_29_060705_create_reporte_table', 1),
	(14, '2025_08_29_060705_create_usuario_table', 1),
	(15, '2025_08_29_060705_create_vehiculo_table', 1),
	(16, '2025_08_29_060708_add_foreign_keys_to_area_table', 1),
	(17, '2025_08_29_060708_add_foreign_keys_to_asignacion_table', 1),
	(18, '2025_08_29_060708_add_foreign_keys_to_electronico_table', 1),
	(19, '2025_08_29_060708_add_foreign_keys_to_empleado_table', 1),
	(20, '2025_08_29_060708_add_foreign_keys_to_equipo_table', 1),
	(21, '2025_08_29_060708_add_foreign_keys_to_herramienta_table', 1),
	(22, '2025_08_29_060708_add_foreign_keys_to_imagen_table', 1),
	(23, '2025_08_29_060708_add_foreign_keys_to_log_movimiento_table', 1),
	(24, '2025_08_29_060708_add_foreign_keys_to_mantenimiento_table', 1),
	(25, '2025_08_29_060708_add_foreign_keys_to_mobiliario_table', 1),
	(26, '2025_08_29_060708_add_foreign_keys_to_reporte_table', 1),
	(27, '2025_08_29_060708_add_foreign_keys_to_vehiculo_table', 1),
	(28, '2025_08_29_061945_create_sessions_table', 1),
	(29, '2025_08_29_071024_create_cache_table', 1),
	(30, '2025_09_16_203515_add_tipo_elemento_to_equipo_table', 1);

-- Volcando datos para la tabla inventario_inmuebles.mobiliario: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.reporte: ~0 rows (aproximadamente)

-- Volcando datos para la tabla inventario_inmuebles.sesiones: ~14 rows (aproximadamente)
INSERT IGNORE INTO `sesiones` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
	('6in4a6HIctSVX93lrZYIdlPCdnyRNaTzRDxHYzWK', NULL, '127.0.0.1', 'curl/8.5.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibER0Y0V3QVZIRnBHUVhraUdyREZQQVQ2QUhYSGpGcTQzUHZYV3g3TCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1760772168),
	('6Z3T4MBLXocN6ems8Nl7woN9A906O5J8CFk1Q8lX', NULL, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ3JIa1A3MVlta0RGWUllTXU5ZFYyamRITnV5UGVLRU12UHI0d2tsbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1760773736),
	('BjmnxkbS9EOxDNM9IptsIi7PrxsoNSULvKFFCkt5', 1, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVWlOVmdqTmY3TUVqdGdGd2dMdGFBMVV5SmJkazJmV21vNjhuMGljdCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9hdXRvLWxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTt9', 1760773296),
	('F6XsrkHLEXljsUnjh5MlXDz6xDNsm28FqPOGzN1X', 1, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQmdvU1E1enlsTElmWlIwQzAzc0NiVldBckZRWEFsUmh5Vzg5ODZpNSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1760773708),
	('fbkXau7uqSI7XV9f9IAXrFPJ4TS8CjINqTCAy7m1', NULL, '127.0.0.1', 'curl/8.5.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQmRNdkkzQkRGUnNYbzJOODNSODhZTFczeVZYSjRYTVJRT2ZJa0xYMyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9kZWJ1Zy1hdXRoIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1760773016),
	('gfJ2Q1AfyzVQxxmf3SxP5DVgVJ4rbSNBcIxZotiR', 1, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQktYdTQxUUlXcWh3Smp2T2dnQUViZTRrcEJIOUc5REUzSk44Vll0bSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1760772593),
	('IHv0ToO6WUeOZfDfkROIguuUGo4wm5ziPjymY8wx', NULL, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoieEluc0I1bmpadm1CYU85WnVwcVZheFNrRXlPNTVqeXZyclZoQzRDSiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1760772277),
	('LljQTP4G5hY4g4uejDJYXcfCFWGCGGrebGVj4H45', 1, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSXkzNUQzZVlMUUtKM3V5aWEzSWRHMjNranFOTXBpeU1ZaGp3dkdlNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1760772609),
	('mhdkf79vKJWiMan7qiNbjjMbrr0ZK8uEKcIyn3uD', 1, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiTWNHOElZQ3hEWXVMT2NIcml3bHpmbUpoZHNXc0JDTEl1YWpTclZmQiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1760772601),
	('Q8aYtSv9i3L4v2B68KqkLgwAmNJzGYUapLctDpX4', 1, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaGF6bmZWeWRLNVdmaU9OeHlGRjRKNHBwcUtkOHY5U1VTVnVuVGRmdyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1760772301),
	('Ql8FnbFXCZ6jDdZjEzzwarzphePoWjN1HCDJnL7N', NULL, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoiT2FHNW95cURqTFlBQU42SThWRW8wNGlNdGY4NlJoZHdZNnZ1V3FYTyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1760772278),
	('rJainvKyUyclNwteDNPMCMJFUEU12cAww6gtCpLs', 1, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoidkxyUTZqekZiTEhpOHlDM0NQZmpJamZkbDlhZXJ0MVRoUnBGaEJheiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1760773697),
	('uwL1aBifkaAR5h8QLejshUwUUTLrJQBX4Qw1Db7F', 1, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiWGxxQ2d4cFdkQU1mMzRsWHJGamNpeFZobmFzdjQxaEhaTVlvSExkUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1760772739),
	('XLuHB5kBxakRDq1jK5QiZJ8fX1aG984mjuJDbUr4', 1, '127.0.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaDJRSFByaTFLM3E3MXB3Q2NwYUxzWVhCNnBXdnpFdFhzOUx6Y01YaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1760773736);

-- Volcando datos para la tabla inventario_inmuebles.usuario: ~1 rows (aproximadamente)
INSERT IGNORE INTO `usuario` (`id`, `nombres`, `apellidos`, `email`, `telefono`, `dpi`, `usuario`, `is_admin`, `is_superuser`, `superuser_username`, `superuser_password`, `roles`, `password`, `remember_token`, `fecha_commit`) VALUES
	(1, 'Admin', 'Sistema', 'admin@sistema.com', '12345678', '1234567890101', 'admin', 1, 1, NULL, NULL, NULL, '$2y$12$8ngrF7yvT2fm9whMUgg60.zuDRp38DThBj9O1VRuA5qqUYGoLxBIe', 'n78s8A4WbR2KcZCTrhIxMXJz4zpZMn3f4kJLUjWb5OPV2b9tP6TVjJ1Psbik', '2025-10-17 21:20:33'),
	(2, 'ALEXANDER', 'PEREZ SOTO', 'sotoperezalexander@gmail.com', '09876567', '1234 34523 1910', 'alexandersoto', 1, 0, NULL, NULL, NULL, '$2y$12$rAKmcF4LaMMuNuKsIynHyelw.lZz8cenr.fuFmjPGJjZc4Yf/5mmy', NULL, '2025-10-18 03:35:16');

-- Volcando datos para la tabla inventario_inmuebles.vehiculo: ~0 rows (aproximadamente)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
