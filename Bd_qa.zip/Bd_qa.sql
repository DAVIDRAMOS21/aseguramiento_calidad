-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.11.13-MariaDB-0ubuntu0.24.04.1 - Ubuntu 24.04
-- SO del servidor:              debian-linux-gnu
-- HeidiSQL Versión:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

-- La exportación de datos fue deseleccionada.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
